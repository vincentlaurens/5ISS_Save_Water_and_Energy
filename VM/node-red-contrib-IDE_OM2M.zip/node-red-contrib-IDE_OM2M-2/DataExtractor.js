"use strict"; 
var DOMParser = require('xmldom').DOMParser;
var XML = require('pixl-xml'); 
var jsonPath = require('JSONPath');
module.exports = function(RED) {
    function DataExtractor(n) {
        RED.nodes.createNode(this,n);
		var node = this;
	    var viewtype=n.viewtype;
	    var property=n.viewunid1;
		var path=n.viewunid2;
        this.on("input", function (msg) {
			var prop="";
         if (viewtype=="autre" ){
			 prop=property; 	 
		 } else { 
			 if (viewtype=="xpath" ){
			 prop=path; 	 
		 }
		   else {
		   prop=viewtype; }
	    }
		 
		 if (msg.topic=="server")
		 {
			 var  newMsg1=msg.payload;
			 var doc1 = XML.parse( newMsg1);
		     var b=doc1["nev"];
             var c=	b["rep"]; 
             var d=c.con; 
             doc1 = XML.parse(d);	
		 }
		 else {		 
		 var a=JSON.parse(msg.payload);	  
	     var b=a["m2m:cin"];
		 var newMsg = { payload: b.con};
         var newMsg1=newMsg.payload;
		 var doc1 = XML.parse(newMsg1);
		 msg={ payload: doc1};
         
		 }
		
		 //For simplicity reasons, oBIX contains only the following simple data types: bool, int, real, string, enum, absTime and relTime.
		 var stat="";
		 var i=0;
		 var k;
		 if (viewtype=="xpath" ){
			 
			var input = msg.payload; 
                // Evalute the JSONPath expresssion
            var evalResult = jsonPath.eval(input, path);
            if (!node.split) {
                    // Batch it in one message. Carry pre-existing properties
                    msg.payload = evalResult;
					msg={payload: msg.payload}; 
					console.log("!node.split")
                    node.send(msg);
            } else {
                    // Send one message per match result
                    var response = evalResult.map(function (value) {
                     return {"payload": value};
                    });
					msg={payload: value}; 
                    node.send(msg);
                } 
		 }
		else {
		if (typeof(doc1.str)!=="undefined") { 
		 var j=doc1.str.length; 
		 if (typeof(j)=="undefined") { 
			 if (doc1.str.name==prop)   
			 stat=doc1.str.val+"";					 
			} 
		 else{
		 while (i<doc1.str.length)
		 {
			 if (doc1.str[i].name==prop)
		        {stat=doc1.str[i].val+"";} 
			i++; 
		 }
		 }
		 }   
		 i=0;
		 if (typeof(doc1.bool)!=="undefined"){
		 j=doc1.bool.length; 
		 if (typeof(j)=="undefined") {if (doc1.bool.name==prop)   
		 stat=doc1.bool.val;
		} 
		 else{
		 while (i<doc1.bool.length)
		 {
			 if (doc1.bool[i].name==prop)
		        {stat=doc1.bool[i].val;} 
			i++;
		 
		 }
		 } 
		}
		 i=0;
		 if (typeof(doc1.enum)!=="undefined"){
		 j=doc1.enum.length; 
		 if (typeof(j)=="undefined") {if (doc1.enum.name==prop)   
		                             stat=doc1.enum.val;} 
		 else{
		 while (i<doc1.enum.length)
		 {
			 if (doc1.enum[i].name==prop)
		        {stat=doc1.enum[i].val;} 
			i++;
		 
		 }
		 }
		 }
		 
		 i=0;
		 if (typeof(doc1.int)!=="undefined"){	 
		 j=doc1.int.length; 
		 if (typeof(j)=="undefined") 
		 {  
			 if (doc1.int.name==prop)   
		     {  stat=doc1.int.val;  
			 }
		 } 
		 else{
		 while (i<doc1.int.length)
		 {
			 if (doc1.int[i].name==prop)
		        {
				  stat=doc1.int[i].val;
				 } 
			i++;
		 }
		 }
		 }
		 i=0;
		 if (typeof(doc1.real)!=="undefined"){
		 j=doc1.real.length; 
		 if (typeof(j)=="undefined") {if (doc1.real.name==prop)   
		                             stat=doc1.real.val;} 
		 else{
		 while (i<doc1.real.length)
		 {
			 if (doc1.real[i].name==prop)
		        {stat=doc1.real[i].val;} 
			i++;
		 
		 }
		 }
		 }
		 i=0;
		 
		 if (typeof(doc1.time)!=="undefined"){
		 j=doc1.time.length; 
		 if (typeof(j)=="undefined") {if (doc1.time.name==prop)   
		                             stat=doc1.time.val;} 
		 else{
		 while (i<doc1.time.length)
		 {
			 if (doc1.time[i].name==prop)
		        {stat=doc1.time[i].val;} 
			i++;
		 }
		 }
		 } 
		 i=0;
		 if (typeof(doc1.abstime)!=="undefined"){
		 j=doc1.abstime.length; 
		 if (typeof(j)=="undefined") {if (doc1.abstime.name==prop)   
		                             stat=doc1.abstime.val;} 
		 else{
		 while (i<doc1.abstime.length)
		 {
			 if (doc1.abstime[i].name==prop)
		        {stat=doc1.abstime[i].val;} 
			i++;
		 
		 }
		 }
		 }
		 i=0;
		 
		 if (typeof(doc1.reltime)!=="undefined"){	 
		 j=doc1.reltime.length; 
		 if (typeof(j)=="undefined") {if (doc1.reltime.name==prop)   
		                             stat=doc1.reltime.val;} 
		 else{
		 while (i<doc1.reltime.length)
		 {
			 if (doc1.reltime[i].name==prop)
		        {stat=doc1.reltime[i].val;} 
			i++;
		 }
		 }		
		 }
		 
		 msg={ payload: stat};
		 node.send(msg); 
		}
		});  
		
		this.on("close", function() {
           
        });
    }
	
    RED.nodes.registerType("DataExtractor",DataExtractor);
	
	
}