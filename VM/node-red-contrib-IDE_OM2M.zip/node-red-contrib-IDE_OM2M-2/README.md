# node-red-contrib-om2m
Set of node-red nodes to create IoT/M2M applications on top of [OM2M platform] (http://www.eclipse.org/om2m/).

Copyright 2015 [the Apache 2.0 license](https://www.apache.org/licenses/LICENSE-2.0).
