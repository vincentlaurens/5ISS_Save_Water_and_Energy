"use strict";
var http = require('http');
var request = require('request');
module.exports = function(RED) {
    function NotificationsHandler(n) {
        RED.nodes.createNode(this,n);
		var host= n.host;
		var port=n.port; 
		var context=n.context; 
		var body = '';
		var node = this;
  node.configure = function(node) {
    http.createServer(function(request, response) {
  var headers = request.headers;
  var method = request.method;
  var url = request.url;
   if (method == 'POST') {
        
        request.on('data', function (data) {
		    body="";
            body += data;
            console.log("Partial body: " + body);
        });
	
        request.on('end', function () {
			var msg={_msgid: "", topic:"server", payload: body};
            node.send(msg);
            console.log("Body: " + body);
        });
        response.writeHead(200, {'Content-Type': 'application/xml'});
        response.end('post received');
    }
	else {
         request.on('error', function(err) {
         console.error(err);
          }).on('data', function(data) {
         body += data;
        }).on('end', function() {
	var msg={_msgid: "", topic:"server", payload: body};
	 node.send(msg);
	});}
    }).listen(port, host,context); // Activates this server, listening on port 1400.
    console.log("Server running at http://"+host+":"+port+context);
    };      
    }
    RED.nodes.registerType("NotificationsHandler",NotificationsHandler);
	 RED.httpAdmin.post("/server/:id", RED.auth.needsPermission("config.write"), function(req,res) {
        var node = RED.nodes.getNode(req.params.id);
        if (node != null) {
            try {
                node.configure(node);
                res.sendStatus(200);
            } catch(err) {
                res.sendStatus(500);
                node.error("Config failed: "+ err.toString());
            }
        } else {
            res.sendStatus(404);
        }
    });
}