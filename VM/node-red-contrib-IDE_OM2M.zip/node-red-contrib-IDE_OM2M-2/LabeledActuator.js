"use strict";
var request = require('request');
var DOMParser = require('xmldom').DOMParser;
var XML = require('pixl-xml');
module.exports = function (RED) {

  function HTTPRequest(n) {
    RED.nodes.createNode(this, n);
    var node = this;
	var platform=n.platform;
	var options=n.options; 
    var height= n.options.length; 
	var command=n.command; 
    var nodeMethod = "POST";
	
	if (RED.settings.httpRequestTimeout) {
      this.reqTimeout = parseInt(RED.settings.httpRequestTimeout) || 120000;
    } else {
      this.reqTimeout = 120000;
    }

    this.on("input", function (msg) {
		
      var preRequestTimestamp = process.hrtime();
      node.status({
        fill: "blue",
        shape: "dot",
        text: "httpin.status.requesting"
      });
	   var url="";
	   var urlBase=node.context().global.get("host"+platform);
	   var labels="?fu=1&lbl="
	   var i;
       for (i=0;i<height-1;i++)
	   {
		labels=labels+options[i].label+"/"+options[i].value+"&lbl=";		
	    } 
	   labels=labels+options[i].label+"/"+options[i].value; 
	   var arrayOfStrings = urlBase.split("/");
	   url=arrayOfStrings[0]+"//"+arrayOfStrings[2]+"/~/"+arrayOfStrings[4]+labels; 
	   var method = "GET";			
		 
      console.log(url);
      if (!url) {
        node.error(RED._("httpin.errors.no-url"), msg);
        node.status({
          fill: "red",
          shape: "ring",
          text: (RED._("httpin.errors.no-url"))
        });
        return;
      }
      // url must start http:// or https:// so assume http:// if not set
      if (!((url.indexOf("http://") === 0) || (url.indexOf("https://") === 0))) {
        if (tlsNode) {
          url = "https://" + url;
        } else {
          url = "http://" + url;
        }
      }
      if (msg.method && n.method && (n.method !== "use")) { // warn if override option not set
        node.warn(RED._("common.errors.nooverride"));
      }
      if (msg.method && n.method && (n.method === "use")) {
        method = msg.method.toUpperCase(); // use the msg parameter
      }  
	  var origin; 
	  var usr = node.context().global.get("userAuth"+platform);
	  var passw = node.context().global.get("passwordAuth"+platform);
	  origin=usr+":"+passw;   
	  var opts = {
         method: method,
         url: url,
         timeout: node.reqTimeout,
         headers: {"Content-type" : "application/json",
         "X-M2M-Origin": origin },
		 body:""
      };
	   msg.headers = {
          "Content-type" : "application/json",
          "X-M2M-Origin": origin
     };  
	 
   if (msg.payload && (method == "POST" || method == "PUT" || method == "PATCH")) {
        if (opts.headers['content-type'] == 'application/x-www-form-urlencoded') {
          opts.form = msg.payload;
        } else {
          if (typeof msg.payload === "string" || Buffer.isBuffer(msg.payload)) {
			opts.body = "";
          } else if (typeof msg.payload == "number") {
            opts.body = "";
          } else {
            opts.body = JSON.stringify(msg.payload);
          }
        }
      }
      request(opts, function (error, response, body) {
        node.status({});
        if (error) {
          if (error.code === 'ETIMEDOUT') {
            node.error(RED._("common.notification.errors.no-response"), msg);
            setTimeout(function () {
              node.status({
                fill: "red",
                shape: "ring",
                text: "common.notification.errors.no-response"
              });
            }, 10);
          } else {
			
            node.error(error, msg);
            msg.payload = error.toString() + " : " + url;
            msg.statusCode = error.code;
            node.send(msg);
            node.status({
              fill: "red",
              shape: "ring",
              text: error.code
            });
          }
        } else {
          msg.payload = body;
          msg.headers = response.headers;
          if (node.metric()) {
            // Calculate request time
            var diff = process.hrtime(preRequestTimestamp);
            var ms = diff[0] * 1e3 + diff[1] * 1e-6;
            var metricRequestDurationMillis = ms.toFixed(3);
            node.metric("duration.millis", msg, metricRequestDurationMillis);
            if (response.connection && response.connection.bytesRead) {
              node.metric("size.bytes", msg, response.connection.bytesRead);
            }
          }

		 var a=JSON.parse(msg.payload);
		 var b=a["m2m:uril"];
         msg = { payload:b};  
		 var arrayOfStrings3 = (msg.payload).split(" ");
		 var uri=arrayOfStrings3[0];
		 var arrayOfStrings1 = urlBase.split("/");
		 url=arrayOfStrings1[0]+"//"+arrayOfStrings1[2]+"/~"+uri+"?"+command;           
	     method ="POST";
         if (msg.method ) { // warn if override option not set
          node.warn(RED._("common.errors.nooverride"));
         }
         if (msg.method) {
          method = msg.method.toUpperCase(); // use the msg parameter
          }
      var opts = {
        method: method,
        url: url,
        timeout: node.reqTimeout,
        headers: {}
      };
      
	   msg.headers = {
         "Content-type" : "application/json",
          "X-M2M-Origin": origin
     };  
	
      if (msg.headers) {
        for (var v in msg.headers) {
          if (msg.headers.hasOwnProperty(v)) {
            var name = v.toLowerCase();
            if (name !== "content-type" && name !== "content-length") {
              // only normalise the known headers used later in this
              // function. Otherwise leave them alone.
              name = v;
            }
            opts.headers[name] = msg.headers[v];
          }
        }
      }

		if (msg.payload && (method == "POST" || method == "PUT" || method == "PATCH")) {
        if (opts.headers['content-type'] == 'application/x-www-form-urlencoded') {
          opts.form = msg.payload;
        } else {
          if (typeof msg.payload === "string" || Buffer.isBuffer(msg.payload)) {
			opts.body = "";
          } else if (typeof msg.payload == "number") {
            opts.body = "";
          } else {
            opts.body = JSON.stringify(msg.payload);
          }
        }
      }   
		   
	
		   request(opts, function (error, response, body) {
           node.status({});
           if (error) {
          if (error.code === 'ETIMEDOUT') {
            node.error(RED._("common.notification.errors.no-response"), msg);
            setTimeout(function () {
              node.status({
                fill: "red",
                shape: "ring",
                text: "common.notification.errors.no-response"
              });
            }, 10);
          } else {
            node.error(error, msg);
            msg.payload = error.toString() + " : " + url;
            msg.statusCode = error.code;
            node.send(msg);
            node.status({
              fill: "red",
              shape: "ring",
              text: error.code
            });
          }
        } else {
          msg.payload = body;
          msg.headers = response.headers;
          if (node.metric()) {
            // Calculate request time
            var diff = process.hrtime(preRequestTimestamp);
            var ms = diff[0] * 1e3 + diff[1] * 1e-6;
            var metricRequestDurationMillis = ms.toFixed(3);
            node.metric("duration.millis", msg, metricRequestDurationMillis);
            if (response.connection && response.connection.bytesRead) {
              node.metric("size.bytes", msg, response.connection.bytesRead);
            }
          }
        console.log(msg); 
        node.send(msg);
        }
      })  
      }
      }) 
    });
  }
  RED.nodes.registerType("LabeledActuator", HTTPRequest);  
}
