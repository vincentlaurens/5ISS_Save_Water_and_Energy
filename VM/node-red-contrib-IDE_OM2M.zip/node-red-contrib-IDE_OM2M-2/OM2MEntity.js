"use strict";
module.exports = function(RED) {
 
    function OM2MEntity(n) {
    RED.nodes.createNode(this, n);
      var node = this;
	  var platform=n.platform; 
	  var URLBase=n.URLBase; 
      var user=n.user;
      var password=n.password;
      
	  node.configure = function(node) {	
			node.context().global.set("host"+platform,URLBase);
			node.context().global.set("userAuth"+platform,user);
			node.context().global.set("passwordAuth"+platform,password);
        };
		node.configure(node);
    }
    RED.nodes.registerType("OM2MEntity", OM2MEntity);

    RED.httpAdmin.post("/config/:id", RED.auth.needsPermission("config.write"), function(req,res) {
        var node = RED.nodes.getNode(req.params.id);
        if (node != null) {
            try {
                node.configure(node);
                res.sendStatus(200);
            } catch(err) {
                res.sendStatus(500);
                node.error("Config failed: "+ err.toString());
            }
        } else {
            res.sendStatus(404);
        }
    });
};
