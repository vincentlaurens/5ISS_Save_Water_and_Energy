"use strict";
var request = require('request');
module.exports = function (RED) {

  function HTTPRequest(n) {
    RED.nodes.createNode(this, n);
    var node = this;
	var platform=n.platform;
	var nameActuator=n.actuator;
	var command=n.command; 
    var nodeMethod = "POST";

	if (RED.settings.httpRequestTimeout) {
      this.reqTimeout = parseInt(RED.settings.httpRequestTimeout) || 120000;
    } else {
      this.reqTimeout = 120000;
    }
	
    this.on("input", function (msg) {
		
     var preRequestTimestamp = process.hrtime();
      node.status({
        fill: "blue",
        shape: "dot",
        text: "httpin.status.requesting"
      });
	   var url="";
	   var urlBase=node.context().global.get("host"+platform);
      url=urlBase+"/"+nameActuator+"?"+command;
	  var method = "POST";	
      if (!url) {
        node.error(RED._("httpin.errors.no-url"), msg);
        node.status({
          fill: "red",
          shape: "ring",
          text: (RED._("httpin.errors.no-url"))
        });
        return;
      }

      if (msg.method && n.method && (n.method !== "use")) { // warn if override option not set
        node.warn(RED._("common.errors.nooverride"));
      }
      if (msg.method && n.method && (n.method === "use")) {
        method = msg.method.toUpperCase(); // use the msg parameter
      }
	  
	  var origin; 
	  var usr = node.context().global.get("userAuth"+platform);
	  var passw = node.context().global.get("passwordAuth"+platform);

		origin=usr+":"+passw;  //� modifier  
	
	 var opts = {
        method: method,
        url: url,
        timeout: node.reqTimeout,
        headers: {"Content-type" : "application/json",
          "X-M2M-Origin": origin },
		body:""
      };
	 
	   msg.headers = {
         "Content-type" : "application/json",
          "X-M2M-Origin": origin
     };  
	 
   if (msg.payload && (method == "POST" || method == "PUT" || method == "PATCH")) {
        if (opts.headers['content-type'] == 'application/x-www-form-urlencoded') {
          opts.form = msg.payload;
        } else {
          if (typeof msg.payload === "string" || Buffer.isBuffer(msg.payload)) {
			opts.body = "";
          } else if (typeof msg.payload == "number") {
            opts.body = "";
          } else {
            opts.body = JSON.stringify(msg.payload);
          }
        }
      }
      request(opts, function (error, response, body) {
        node.status({});
        if (error) {
          if (error.code === 'ETIMEDOUT') {
            node.error(RED._("common.notification.errors.no-response"), msg);
            setTimeout(function () {
              node.status({
                fill: "red",
                shape: "ring",
                text: "common.notification.errors.no-response"
              });
            }, 10);
          } else {
			
            node.error(error, msg);
            msg.payload = error.toString() + " : " + url;
            msg.statusCode = error.code;
            node.send(msg);
            node.status({
              fill: "red",
              shape: "ring",
              text: error.code
            });
          }
        } else {
          msg.payload = body;
          msg.headers = response.headers;
          if (node.metric()) {
            // Calculate request time
            var diff = process.hrtime(preRequestTimestamp);
            var ms = diff[0] * 1e3 + diff[1] * 1e-6;
            var metricRequestDurationMillis = ms.toFixed(3);
            node.metric("duration.millis", msg, metricRequestDurationMillis);
            if (response.connection && response.connection.bytesRead) {
              node.metric("size.bytes", msg, response.connection.bytesRead);
            }
          }   
          node.send(msg);
        }
      }) 
  
    });
  }

  RED.nodes.registerType("NamedActuator", HTTPRequest);  
}
