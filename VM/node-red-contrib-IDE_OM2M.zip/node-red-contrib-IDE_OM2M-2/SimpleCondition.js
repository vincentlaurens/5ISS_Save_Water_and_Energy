'use strict';
module.exports = function(RED) {
    function SimpleCondition(n) {
        RED.nodes.createNode(this,n);
         var operator = n.operator;
	     var value_c = n.value_c;
		 var code = true;
		 var codeElse = false;
		 
        this.on("input", function (msg) {
		if (!isNaN(msg.payload)){
	    msg.payload= parseInt(msg.payload);} 
		if (!isNaN(value_c)){
		value_c = parseInt(value_c);}
		switch(operator) {
        case "=": {
		if (msg.payload == value_c){
			 msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid,payload: true};
		  this.send(msg);
		}
		else {
	      msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid,payload: false};
		  this.send(msg);
		}
		}  
        break;
       case "<": {
	   if (msg.payload < value_c){
		    msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid, payload: true};
		   this.send(msg);
		   
		}
		else {
		   msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid,payload: false};
		  this.send(msg);
		}
	   }
        break;
		case "<=": {
	   if (msg.payload <= value_c){
		    msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid,payload: true};
		   this.send(msg);
		  console.log(msg.payload);
		}
		else {
		 msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid, payload: false};
		 this.send(msg);
		}
		}
        break;
		
		case ">": {
	   if (msg.payload > value_c){
		    msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid, payload: true};
		   this.send(msg);
		}
		else {
		  msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid,payload: false};
		  this.send(msg);
		}
		}
        break;
		
		case ">=": 
		{
		
		
	   if (msg.payload >= value_c){
	      msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid,payload: true};
		  this.send(msg);
		  
		}
		else {
		msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid,payload: false};
		  this.send(msg);
		}
		}
        break;
		
      default:
       if (msg.payload != value_c){
		    msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid,payload: true};
		   this.send(msg);
			
		}
		else {
		  msg = {_msgid: msg._msgid, topic:"topic"+msg._msgid, payload: false};
		  this.send(msg);
		}
      }
		 
		});  
    }
    RED.nodes.registerType("SimpleCondition",SimpleCondition);
}